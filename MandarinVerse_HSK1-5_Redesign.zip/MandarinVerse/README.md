# MandarinVerse

Aplikasi belajar Mandarin berbasis HTML, CSS, JavaScript Modules, Firebase Authentication, dan Firebase Hosting.

## Struktur
```text
MandarinVerse/
├── public/
│   ├── index.html
│   ├── login.html
│   ├── register.html
│   ├── css/ (style, dashboard, lesson, quiz, responsive)
│   ├── js/ (app, auth, dashboard, lesson, quiz, weekly-exam, vocabulary, review, progress, greeting, firebase)
│   ├── data/ (level-0, level-1, quiz-data)
│   └── assets/images/
├── firebase.json
├── .firebaserc
└── README.md
```

## Fitur versi ini
- Navigasi bawah ala aplikasi mobile.
- Tampilan responsif untuk HP dan desktop.
- Dashboard, materi harian, kamus HSK 1, review flashcard, daily quiz, ujian mingguan, progress, dan profil.
- 150 kosakata HSK 1 (daftar HSK 1 format lama/HSK 2.0) dengan hanzi, pinyin bertanda nada, arti, dan kategori.
- Progress penguasaan kata dan XP disimpan di `localStorage` browser.
- Firebase Authentication Email/Password untuk daftar dan login.

## Roadmap HSK
MandarinVerse menampilkan jalur HSK 1 sampai HSK 5. Fokus konten yang sudah disiapkan pada rilis ini adalah HSK 1. Level 2–5 masih berupa roadmap, bukan materi lengkap. Daftar 150 kata mengacu pada daftar HSK 1 yang umum dipakai pada standar HSK 2.0; standar HSK 3.0 memiliki cakupan berbeda dan dapat berubah.

## Catatan penting
1. Progress saat ini tersimpan lokal di perangkat/browser, belum tersinkronisasi ke Firestore. Login Firebase hanya untuk autentikasi.
2. Quiz mingguan versi awal menggunakan kumpulan contoh soal yang tersedia (maksimal 15 variasi), bukan 25 soal unik. Kartu kosakata HSK 1 berjumlah 150.
3. Materi harian awal merupakan pengelompokan pengantar; belum semua 150 kata memiliki lesson audio atau latihan kontekstual.
4. `firebase.js` berisi konfigurasi web app Firebase yang diberikan pemilik project. Firebase web API key bukan password, tetapi jangan pernah mempublikasikan kredensial Admin SDK atau service account.
5. Aktifkan Authentication > Sign-in method > Email/Password di Firebase Console.
6. Pastikan Firebase project `valine-b06ad` adalah project yang memang ingin dipakai. Ganti `.firebaserc` dan `firebase.js` jika project berbeda.

## Menjalankan dan deploy
Jalankan dari folder utama:
```bash
firebase login
firebase use --add   # hanya jika ingin memilih project lain
firebase deploy --only hosting
```

Folder Hosting adalah `public`. Buka `public/index.html` melalui Firebase Hosting, bukan dengan `file://`, karena aplikasi menggunakan JavaScript modules.
