import { sampleQuiz } from "../data/quiz-data.js";
import { recordScore } from "./progress.js";
let state=null;
export function startQuiz(type="daily"){
 const count=type==="weekly"?Math.min(25,sampleQuiz.length):5;
 const questions=[...sampleQuiz].sort(()=>Math.random()-.5).slice(0,count);
 state={type,questions,index:0,correct:0,answered:false};
 render();
}
function render(){
 const host=document.querySelector("#quizArea");host.hidden=false;
 if(state.index>=state.questions.length){const score=Math.round(state.correct/state.questions.length*100);recordScore(score);
 host.innerHTML=`<div class="quiz-result"><div style="font-size:38px">🎉</div><p class="eyebrow">HASIL ${state.type==="weekly"?"UJIAN MINGGUAN":"DAILY QUIZ"}</p><strong>${score}%</strong><h2>${score>=80?"Bagus! Target tercapai.":"Tetap semangat, ulangi lagi ya."}</h2><p class="muted">${state.correct} benar dari ${state.questions.length} soal. ${score>=80?"Kamu mencapai nilai minimal 80%.":"Pelajari kembali kosakata lalu coba lagi."}</p><button class="primary-button" data-action="retry-quiz">Coba lagi</button></div>`;return;}
 const q=state.questions[state.index];
 host.innerHTML=`<div class="quiz-top"><span>${state.type==="weekly"?"WEEKLY EXAM":"DAILY QUIZ"}</span><span>${state.index+1}/${state.questions.length}</span></div><div class="quiz-progress"><i style="width:${(state.index/state.questions.length)*100}%"></i></div><div class="quiz-question"><div class="hanzi">${q.hanzi}</div><div class="pinyin">${q.pinyin}</div><h3>${q.question}</h3></div><div class="quiz-answers">${q.options.map(o=>`<button class="quiz-answer" data-answer="${o}">${o}</button>`).join("")}</div><p id="quizFeedback" class="muted"></p><button id="quizNext" class="primary-button" hidden>${state.index===state.questions.length-1?"Lihat hasil":"Lanjut →"}</button>`;
 host.querySelectorAll("[data-answer]").forEach(b=>b.addEventListener("click",()=>answer(b,q)));
 host.querySelector("#quizNext").addEventListener("click",()=>{state.index++;render();});
}
function answer(button,q){
 if(state.answered)return;state.answered=true;
 const good=button.dataset.answer===q.answer;if(good)state.correct++;
 document.querySelectorAll("[data-answer]").forEach(b=>{b.disabled=true;if(b.dataset.answer===q.answer)b.classList.add("correct");});
 if(!good)button.classList.add("wrong");
 document.querySelector("#quizFeedback").textContent=good?"Benar! Bagus sekali.":`Belum tepat. Jawaban: ${q.answer}`;
 document.querySelector("#quizNext").hidden=false;
}
export function retryQuiz(){startQuiz(state?.type||"daily");}