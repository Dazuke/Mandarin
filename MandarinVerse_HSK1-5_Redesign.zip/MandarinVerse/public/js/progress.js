const KEY = "mandarinverse-progress-v1";
const empty = {mastered:{},xp:0,streak:0,quizScores:[],completedLessons:[]};
export function getProgress(){try{return {...empty,...JSON.parse(localStorage.getItem(KEY)||"{}")};}catch{return {...empty};}}
export function saveProgress(p){localStorage.setItem(KEY,JSON.stringify(p));}
export function markMastered(id){const p=getProgress();p.mastered[id]=!p.mastered[id];if(p.mastered[id])p.xp+=5;saveProgress(p);return p;}
export function addXP(amount){const p=getProgress();p.xp+=amount;saveProgress(p);return p;}
export function recordScore(score){const p=getProgress();p.quizScores.push(score);p.xp+=score>=80?20:5;saveProgress(p);return p;}
export function renderProgress(){
 const p=getProgress(),count=Object.values(p.mastered).filter(Boolean).length,percent=Math.round(count/150*100);
 const set=(id,v)=>{const e=document.getElementById(id);if(e)e.textContent=v;};
 set("learnedCount",count);set("xpCount",`${p.xp} XP`);set("streakCount",p.streak||0);
 set("quizAverage",p.quizScores.length?`${Math.round(p.quizScores.reduce((a,b)=>a+b,0)/p.quizScores.length)}%`:"—");
 set("progressPercent",`${percent}%`);set("progressDetail",`${count} dari 150 kata ditandai dikuasai`);
 const bar=document.getElementById("progressBar");if(bar)bar.style.width=`${percent}%`;
}