import { hsk1Vocabulary } from "../data/level-1.js";
export function openLesson(day){
 const groups=[[0,1,2,3,4],[5,6,7,8,9],[10,11,12,13,14],[15,16,17,18,19],[20,21,22,23,24]];
 const ids=groups[day]||groups[0],words=ids.map(i=>hsk1Vocabulary[i]);
 const host=document.querySelector("#quizArea");host.hidden=false;
 host.innerHTML=`<div class="lesson-detail"><p class="eyebrow">LESSON DAY ${day+1}</p><h3>${["Salam & perkenalan","Angka, umur & waktu","Keluarga & orang","Makanan & minuman","Aktivitas sehari-hari"][day]}</h3><p class="muted">Pelajari hanzi, pinyin, dan arti. Tekan tiap kata untuk mendengarkan pelafalan melalui fitur suara perangkat jika tersedia.</p><div class="lesson-words">${words.map(w=>`<div class="lesson-word"><b>${w.hanzi}</b><div><small>${w.pinyin}</small><span class="meaning">${w.meaning}</span></div></div>`).join("")}</div><button class="primary-button" data-action="daily-quiz" style="margin-top:16px">Selesai, mulai kuis →</button></div>`;
 host.scrollIntoView({behavior:"smooth",block:"start"});
}