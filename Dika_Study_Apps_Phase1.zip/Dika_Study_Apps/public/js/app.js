(function(){
  const saved = localStorage.getItem('dsa-theme') || 'dark';
  document.body.classList.toggle('light', saved === 'light');
  document.querySelectorAll('[data-theme-toggle]').forEach(btn=>{
    btn.addEventListener('click',()=>{
      const light = !document.body.classList.contains('light');
      document.body.classList.toggle('light', light);
      localStorage.setItem('dsa-theme', light ? 'light' : 'dark');
    });
  });
  document.querySelectorAll('[data-demo-form]').forEach(form=>{
    form.addEventListener('submit',e=>{
      e.preventDefault();
      const note=form.querySelector('[data-form-note]');
      if(note) note.textContent='Form berhasil divalidasi di prototype. Hubungkan Firebase Authentication untuk login/registrasi sungguhan.';
      const next=form.dataset.next;
      if(next) setTimeout(()=>location.href=next,700);
    });
  });
})();