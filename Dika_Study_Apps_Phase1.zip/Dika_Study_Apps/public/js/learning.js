const sampleWords = [
 {hanzi:'你好',pinyin:'nǐ hǎo',meaning:'Halo / Hai',female:'assets/audio/hsk1/female/001.mp3',male:'assets/audio/hsk1/male/001.mp3'},
 {hanzi:'谢谢',pinyin:'xièxie',meaning:'Terima kasih',female:'assets/audio/hsk1/female/002.mp3',male:'assets/audio/hsk1/male/002.mp3'},
 {hanzi:'再见',pinyin:'zàijiàn',meaning:'Sampai jumpa',female:'assets/audio/hsk1/female/003.mp3',male:'assets/audio/hsk1/male/003.mp3'},
 {hanzi:'我',pinyin:'wǒ',meaning:'Saya / Aku',female:'assets/audio/hsk1/female/004.mp3',male:'assets/audio/hsk1/male/004.mp3'},
 {hanzi:'你',pinyin:'nǐ',meaning:'Kamu',female:'assets/audio/hsk1/female/005.mp3',male:'assets/audio/hsk1/male/005.mp3'}
];
const audioEl=document.getElementById('word-audio');
document.querySelectorAll('[data-audio]').forEach(btn=>btn.addEventListener('click',()=>{
  if(!audioEl)return;
  const type=btn.dataset.audio;
  const note=document.getElementById('audio-note');
  const word=sampleWords[0];
  audioEl.src='../'+(type==='female'?word.female:word.male);
  audioEl.play().then(()=>{if(note)note.textContent='Memutar rekaman '+type+' voice.'}).catch(()=>{if(note)note.textContent='File audio belum tersedia. Tambahkan rekaman native pada '+audioEl.src;});
}));
document.querySelectorAll('[data-answer]').forEach(btn=>btn.addEventListener('click',()=>{
  const feedback=document.getElementById('answer-feedback');
  document.querySelectorAll('[data-answer]').forEach(b=>b.classList.remove('correct','wrong'));
  if(btn.dataset.correct){btn.classList.add('correct');feedback.textContent='Benar! 你好 berarti Halo. Bagus!';}
  else{btn.classList.add('wrong');feedback.textContent='Belum tepat. Coba ingat kembali arti kosakata hari ini.';}
}));
const complete=document.getElementById('complete-word');
if(complete)complete.addEventListener('click',()=>{
  const done=localStorage.getItem('dsa-day1-done')==='true';
  if(done){complete.textContent='Sudah dipelajari ✓';return;}
  localStorage.setItem('dsa-day1-done','true');
  complete.textContent='Selesai ✓ · +20 XP (demo)';
  complete.disabled=true;
});
const list=document.getElementById('vocabulary-list');
if(list)list.innerHTML=sampleWords.map(w=>`<article class="vocab-item"><strong class="hanzi-small">${w.hanzi}</strong><div><b class="pinyin-small">${w.pinyin}</b><div>${w.meaning}</div></div><span class="meaning-small">HSK 1 sample</span></article>`).join('');
