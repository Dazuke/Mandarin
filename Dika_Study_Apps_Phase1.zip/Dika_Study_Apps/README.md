# Dika Study Apps — Phase 1 UI Foundation

Starter project for the Dika Study Apps personal-learning platform.

## Included
- Responsive landing page, login, register, dashboard, and Mandarin learning screen
- Dark mode by default with a working light-mode toggle
- Mandarin HSK 1 sample vocabulary and daily-word interaction
- Female/Male audio player interface with local audio-file paths
- Daily quiz sample interaction and mini-game navigation placeholders
- Firebase configuration placeholder

## Important
This is the Phase 1 frontend foundation/prototype. It does **not** include 300 verified HSK 3.0 vocabulary records, native-speaker recordings, production Firebase credentials, secure server-side XP validation, or completed weekly exams.

Native audio files are expected under `public/assets/audio/hsk1/female/` and `public/assets/audio/hsk1/male/`.
The sample word's audio paths are documented in `public/data/mandarin/hsk1/vocabulary.json`. Add licensed/authorized native-speaker recordings there.

## Run locally
Open `public/index.html` in a browser, or use a local static server.

For example:
```bash
cd Dika_Study_Apps/public
python -m http.server 8000
```
Then visit http://localhost:8000

## Firebase
1. Create a Firebase project.
2. Enable Authentication (Email/Password).
3. Create Firestore.
4. Copy your web app configuration into `public/js/firebase-config.js`.
5. Do not deploy permissive Firestore rules. Add owner-only user data rules and server-side validation for rewards before production.
