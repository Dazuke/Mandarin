Folder audio disediakan untuk rekaman pelafalan Mandarin pada pengembangan berikutnya.
