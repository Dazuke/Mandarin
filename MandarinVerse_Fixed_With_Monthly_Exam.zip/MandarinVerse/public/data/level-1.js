export const hsk1Vocabulary = [
  {
    "id": 1,
    "hanzi": "爱",
    "pinyin": "ài",
    "meaning": "cinta; suka",
    "category": "verb"
  },
  {
    "id": 2,
    "hanzi": "八",
    "pinyin": "bā",
    "meaning": "delapan",
    "category": "number"
  },
  {
    "id": 3,
    "hanzi": "爸爸",
    "pinyin": "bàba",
    "meaning": "ayah",
    "category": "family"
  },
  {
    "id": 4,
    "hanzi": "杯子",
    "pinyin": "bēizi",
    "meaning": "gelas; cangkir",
    "category": "object"
  },
  {
    "id": 5,
    "hanzi": "北京",
    "pinyin": "Běijīng",
    "meaning": "Beijing",
    "category": "place"
  },
  {
    "id": 6,
    "hanzi": "本",
    "pinyin": "běn",
    "meaning": "kata penggolong buku",
    "category": "measure"
  },
  {
    "id": 7,
    "hanzi": "不",
    "pinyin": "bù",
    "meaning": "tidak",
    "category": "particle"
  },
  {
    "id": 8,
    "hanzi": "不客气",
    "pinyin": "bú kèqi",
    "meaning": "sama-sama",
    "category": "phrase"
  },
  {
    "id": 9,
    "hanzi": "菜",
    "pinyin": "cài",
    "meaning": "sayur; hidangan",
    "category": "food"
  },
  {
    "id": 10,
    "hanzi": "茶",
    "pinyin": "chá",
    "meaning": "teh",
    "category": "food"
  },
  {
    "id": 11,
    "hanzi": "吃",
    "pinyin": "chī",
    "meaning": "makan",
    "category": "verb"
  },
  {
    "id": 12,
    "hanzi": "出租车",
    "pinyin": "chūzūchē",
    "meaning": "taksi",
    "category": "transport"
  },
  {
    "id": 13,
    "hanzi": "打电话",
    "pinyin": "dǎ diànhuà",
    "meaning": "menelepon",
    "category": "verb"
  },
  {
    "id": 14,
    "hanzi": "大",
    "pinyin": "dà",
    "meaning": "besar",
    "category": "adjective"
  },
  {
    "id": 15,
    "hanzi": "的",
    "pinyin": "de",
    "meaning": "partikel kepemilikan",
    "category": "particle"
  },
  {
    "id": 16,
    "hanzi": "点",
    "pinyin": "diǎn",
    "meaning": "jam; titik",
    "category": "time"
  },
  {
    "id": 17,
    "hanzi": "电脑",
    "pinyin": "diànnǎo",
    "meaning": "komputer",
    "category": "object"
  },
  {
    "id": 18,
    "hanzi": "电视",
    "pinyin": "diànshì",
    "meaning": "televisi",
    "category": "object"
  },
  {
    "id": 19,
    "hanzi": "电影",
    "pinyin": "diànyǐng",
    "meaning": "film",
    "category": "object"
  },
  {
    "id": 20,
    "hanzi": "东西",
    "pinyin": "dōngxi",
    "meaning": "barang; benda",
    "category": "noun"
  },
  {
    "id": 21,
    "hanzi": "都",
    "pinyin": "dōu",
    "meaning": "semua",
    "category": "adverb"
  },
  {
    "id": 22,
    "hanzi": "读",
    "pinyin": "dú",
    "meaning": "membaca",
    "category": "verb"
  },
  {
    "id": 23,
    "hanzi": "对不起",
    "pinyin": "duìbuqǐ",
    "meaning": "maaf",
    "category": "phrase"
  },
  {
    "id": 24,
    "hanzi": "多",
    "pinyin": "duō",
    "meaning": "banyak",
    "category": "adjective"
  },
  {
    "id": 25,
    "hanzi": "多少",
    "pinyin": "duōshao",
    "meaning": "berapa",
    "category": "question"
  },
  {
    "id": 26,
    "hanzi": "儿子",
    "pinyin": "érzi",
    "meaning": "anak laki-laki",
    "category": "family"
  },
  {
    "id": 27,
    "hanzi": "二",
    "pinyin": "èr",
    "meaning": "dua",
    "category": "number"
  },
  {
    "id": 28,
    "hanzi": "饭店",
    "pinyin": "fàndiàn",
    "meaning": "restoran; hotel",
    "category": "place"
  },
  {
    "id": 29,
    "hanzi": "飞机",
    "pinyin": "fēijī",
    "meaning": "pesawat",
    "category": "transport"
  },
  {
    "id": 30,
    "hanzi": "分钟",
    "pinyin": "fēnzhōng",
    "meaning": "menit",
    "category": "time"
  },
  {
    "id": 31,
    "hanzi": "高兴",
    "pinyin": "gāoxìng",
    "meaning": "senang",
    "category": "adjective"
  },
  {
    "id": 32,
    "hanzi": "个",
    "pinyin": "gè",
    "meaning": "kata penggolong umum",
    "category": "measure"
  },
  {
    "id": 33,
    "hanzi": "工作",
    "pinyin": "gōngzuò",
    "meaning": "bekerja; pekerjaan",
    "category": "verb"
  },
  {
    "id": 34,
    "hanzi": "狗",
    "pinyin": "gǒu",
    "meaning": "anjing",
    "category": "animal"
  },
  {
    "id": 35,
    "hanzi": "汉语",
    "pinyin": "Hànyǔ",
    "meaning": "bahasa Mandarin",
    "category": "language"
  },
  {
    "id": 36,
    "hanzi": "好",
    "pinyin": "hǎo",
    "meaning": "baik; bagus",
    "category": "adjective"
  },
  {
    "id": 37,
    "hanzi": "喝",
    "pinyin": "hē",
    "meaning": "minum",
    "category": "verb"
  },
  {
    "id": 38,
    "hanzi": "和",
    "pinyin": "hé",
    "meaning": "dan; dengan",
    "category": "conjunction"
  },
  {
    "id": 39,
    "hanzi": "很",
    "pinyin": "hěn",
    "meaning": "sangat",
    "category": "adverb"
  },
  {
    "id": 40,
    "hanzi": "后面",
    "pinyin": "hòumiàn",
    "meaning": "belakang",
    "category": "direction"
  },
  {
    "id": 41,
    "hanzi": "回",
    "pinyin": "huí",
    "meaning": "kembali",
    "category": "verb"
  },
  {
    "id": 42,
    "hanzi": "会",
    "pinyin": "huì",
    "meaning": "bisa; akan",
    "category": "modal"
  },
  {
    "id": 43,
    "hanzi": "火车站",
    "pinyin": "huǒchēzhàn",
    "meaning": "stasiun kereta",
    "category": "place"
  },
  {
    "id": 44,
    "hanzi": "几",
    "pinyin": "jǐ",
    "meaning": "berapa (jumlah kecil)",
    "category": "question"
  },
  {
    "id": 45,
    "hanzi": "家",
    "pinyin": "jiā",
    "meaning": "rumah; keluarga",
    "category": "family"
  },
  {
    "id": 46,
    "hanzi": "叫",
    "pinyin": "jiào",
    "meaning": "bernama; memanggil",
    "category": "verb"
  },
  {
    "id": 47,
    "hanzi": "今天",
    "pinyin": "jīntiān",
    "meaning": "hari ini",
    "category": "time"
  },
  {
    "id": 48,
    "hanzi": "九",
    "pinyin": "jiǔ",
    "meaning": "sembilan",
    "category": "number"
  },
  {
    "id": 49,
    "hanzi": "开",
    "pinyin": "kāi",
    "meaning": "membuka; mengemudi",
    "category": "verb"
  },
  {
    "id": 50,
    "hanzi": "看",
    "pinyin": "kàn",
    "meaning": "melihat; membaca",
    "category": "verb"
  },
  {
    "id": 51,
    "hanzi": "看见",
    "pinyin": "kànjiàn",
    "meaning": "melihat",
    "category": "verb"
  },
  {
    "id": 52,
    "hanzi": "块",
    "pinyin": "kuài",
    "meaning": "yuan; potong",
    "category": "measure"
  },
  {
    "id": 53,
    "hanzi": "来",
    "pinyin": "lái",
    "meaning": "datang",
    "category": "verb"
  },
  {
    "id": 54,
    "hanzi": "老师",
    "pinyin": "lǎoshī",
    "meaning": "guru",
    "category": "person"
  },
  {
    "id": 55,
    "hanzi": "了",
    "pinyin": "le",
    "meaning": "partikel perubahan/aspek",
    "category": "particle"
  },
  {
    "id": 56,
    "hanzi": "冷",
    "pinyin": "lěng",
    "meaning": "dingin",
    "category": "adjective"
  },
  {
    "id": 57,
    "hanzi": "里",
    "pinyin": "lǐ",
    "meaning": "di dalam",
    "category": "direction"
  },
  {
    "id": 58,
    "hanzi": "六",
    "pinyin": "liù",
    "meaning": "enam",
    "category": "number"
  },
  {
    "id": 59,
    "hanzi": "妈妈",
    "pinyin": "māma",
    "meaning": "ibu",
    "category": "family"
  },
  {
    "id": 60,
    "hanzi": "吗",
    "pinyin": "ma",
    "meaning": "partikel pertanyaan",
    "category": "particle"
  },
  {
    "id": 61,
    "hanzi": "买",
    "pinyin": "mǎi",
    "meaning": "membeli",
    "category": "verb"
  },
  {
    "id": 62,
    "hanzi": "猫",
    "pinyin": "māo",
    "meaning": "kucing",
    "category": "animal"
  },
  {
    "id": 63,
    "hanzi": "没关系",
    "pinyin": "méi guānxi",
    "meaning": "tidak apa-apa",
    "category": "phrase"
  },
  {
    "id": 64,
    "hanzi": "没有",
    "pinyin": "méiyǒu",
    "meaning": "tidak punya; tidak ada",
    "category": "verb"
  },
  {
    "id": 65,
    "hanzi": "米饭",
    "pinyin": "mǐfàn",
    "meaning": "nasi",
    "category": "food"
  },
  {
    "id": 66,
    "hanzi": "名字",
    "pinyin": "míngzi",
    "meaning": "nama",
    "category": "noun"
  },
  {
    "id": 67,
    "hanzi": "明天",
    "pinyin": "míngtiān",
    "meaning": "besok",
    "category": "time"
  },
  {
    "id": 68,
    "hanzi": "哪",
    "pinyin": "nǎ",
    "meaning": "yang mana",
    "category": "question"
  },
  {
    "id": 69,
    "hanzi": "哪儿",
    "pinyin": "nǎr",
    "meaning": "di mana",
    "category": "question"
  },
  {
    "id": 70,
    "hanzi": "那",
    "pinyin": "nà",
    "meaning": "itu",
    "category": "pronoun"
  },
  {
    "id": 71,
    "hanzi": "呢",
    "pinyin": "ne",
    "meaning": "partikel tanya/topik",
    "category": "particle"
  },
  {
    "id": 72,
    "hanzi": "能",
    "pinyin": "néng",
    "meaning": "dapat; mampu",
    "category": "modal"
  },
  {
    "id": 73,
    "hanzi": "你",
    "pinyin": "nǐ",
    "meaning": "kamu",
    "category": "pronoun"
  },
  {
    "id": 74,
    "hanzi": "年",
    "pinyin": "nián",
    "meaning": "tahun",
    "category": "time"
  },
  {
    "id": 75,
    "hanzi": "女儿",
    "pinyin": "nǚ'ér",
    "meaning": "anak perempuan",
    "category": "family"
  },
  {
    "id": 76,
    "hanzi": "朋友",
    "pinyin": "péngyou",
    "meaning": "teman",
    "category": "person"
  },
  {
    "id": 77,
    "hanzi": "漂亮",
    "pinyin": "piàoliang",
    "meaning": "cantik; indah",
    "category": "adjective"
  },
  {
    "id": 78,
    "hanzi": "苹果",
    "pinyin": "píngguǒ",
    "meaning": "apel",
    "category": "food"
  },
  {
    "id": 79,
    "hanzi": "七",
    "pinyin": "qī",
    "meaning": "tujuh",
    "category": "number"
  },
  {
    "id": 80,
    "hanzi": "钱",
    "pinyin": "qián",
    "meaning": "uang",
    "category": "noun"
  },
  {
    "id": 81,
    "hanzi": "前面",
    "pinyin": "qiánmiàn",
    "meaning": "depan",
    "category": "direction"
  },
  {
    "id": 82,
    "hanzi": "请",
    "pinyin": "qǐng",
    "meaning": "silakan; tolong",
    "category": "phrase"
  },
  {
    "id": 83,
    "hanzi": "去",
    "pinyin": "qù",
    "meaning": "pergi",
    "category": "verb"
  },
  {
    "id": 84,
    "hanzi": "热",
    "pinyin": "rè",
    "meaning": "panas",
    "category": "adjective"
  },
  {
    "id": 85,
    "hanzi": "人",
    "pinyin": "rén",
    "meaning": "orang",
    "category": "person"
  },
  {
    "id": 86,
    "hanzi": "认识",
    "pinyin": "rènshi",
    "meaning": "mengenal",
    "category": "verb"
  },
  {
    "id": 87,
    "hanzi": "三",
    "pinyin": "sān",
    "meaning": "tiga",
    "category": "number"
  },
  {
    "id": 88,
    "hanzi": "商店",
    "pinyin": "shāngdiàn",
    "meaning": "toko",
    "category": "place"
  },
  {
    "id": 89,
    "hanzi": "上",
    "pinyin": "shàng",
    "meaning": "atas",
    "category": "direction"
  },
  {
    "id": 90,
    "hanzi": "上午",
    "pinyin": "shàngwǔ",
    "meaning": "pagi menjelang siang",
    "category": "time"
  },
  {
    "id": 91,
    "hanzi": "少",
    "pinyin": "shǎo",
    "meaning": "sedikit",
    "category": "adjective"
  },
  {
    "id": 92,
    "hanzi": "谁",
    "pinyin": "shéi",
    "meaning": "siapa",
    "category": "question"
  },
  {
    "id": 93,
    "hanzi": "什么",
    "pinyin": "shénme",
    "meaning": "apa",
    "category": "question"
  },
  {
    "id": 94,
    "hanzi": "十",
    "pinyin": "shí",
    "meaning": "sepuluh",
    "category": "number"
  },
  {
    "id": 95,
    "hanzi": "时候",
    "pinyin": "shíhou",
    "meaning": "waktu; saat",
    "category": "time"
  },
  {
    "id": 96,
    "hanzi": "是",
    "pinyin": "shì",
    "meaning": "adalah",
    "category": "verb"
  },
  {
    "id": 97,
    "hanzi": "书",
    "pinyin": "shū",
    "meaning": "buku",
    "category": "object"
  },
  {
    "id": 98,
    "hanzi": "水",
    "pinyin": "shuǐ",
    "meaning": "air",
    "category": "food"
  },
  {
    "id": 99,
    "hanzi": "水果",
    "pinyin": "shuǐguǒ",
    "meaning": "buah",
    "category": "food"
  },
  {
    "id": 100,
    "hanzi": "睡觉",
    "pinyin": "shuìjiào",
    "meaning": "tidur",
    "category": "verb"
  },
  {
    "id": 101,
    "hanzi": "说",
    "pinyin": "shuō",
    "meaning": "berbicara",
    "category": "verb"
  },
  {
    "id": 102,
    "hanzi": "四",
    "pinyin": "sì",
    "meaning": "empat",
    "category": "number"
  },
  {
    "id": 103,
    "hanzi": "岁",
    "pinyin": "suì",
    "meaning": "tahun (usia)",
    "category": "measure"
  },
  {
    "id": 104,
    "hanzi": "他",
    "pinyin": "tā",
    "meaning": "dia (laki-laki)",
    "category": "pronoun"
  },
  {
    "id": 105,
    "hanzi": "她",
    "pinyin": "tā",
    "meaning": "dia (perempuan)",
    "category": "pronoun"
  },
  {
    "id": 106,
    "hanzi": "太",
    "pinyin": "tài",
    "meaning": "terlalu; sangat",
    "category": "adverb"
  },
  {
    "id": 107,
    "hanzi": "天气",
    "pinyin": "tiānqì",
    "meaning": "cuaca",
    "category": "noun"
  },
  {
    "id": 108,
    "hanzi": "听",
    "pinyin": "tīng",
    "meaning": "mendengar",
    "category": "verb"
  },
  {
    "id": 109,
    "hanzi": "同学",
    "pinyin": "tóngxué",
    "meaning": "teman sekelas",
    "category": "person"
  },
  {
    "id": 110,
    "hanzi": "喂",
    "pinyin": "wèi",
    "meaning": "halo (telepon)",
    "category": "phrase"
  },
  {
    "id": 111,
    "hanzi": "我",
    "pinyin": "wǒ",
    "meaning": "saya; aku",
    "category": "pronoun"
  },
  {
    "id": 112,
    "hanzi": "我们",
    "pinyin": "wǒmen",
    "meaning": "kami; kita",
    "category": "pronoun"
  },
  {
    "id": 113,
    "hanzi": "五",
    "pinyin": "wǔ",
    "meaning": "lima",
    "category": "number"
  },
  {
    "id": 114,
    "hanzi": "喜欢",
    "pinyin": "xǐhuan",
    "meaning": "suka",
    "category": "verb"
  },
  {
    "id": 115,
    "hanzi": "下",
    "pinyin": "xià",
    "meaning": "bawah; berikutnya",
    "category": "direction"
  },
  {
    "id": 116,
    "hanzi": "下午",
    "pinyin": "xiàwǔ",
    "meaning": "sore",
    "category": "time"
  },
  {
    "id": 117,
    "hanzi": "下雨",
    "pinyin": "xiàyǔ",
    "meaning": "hujan",
    "category": "weather"
  },
  {
    "id": 118,
    "hanzi": "先生",
    "pinyin": "xiānsheng",
    "meaning": "Tuan; Bapak",
    "category": "person"
  },
  {
    "id": 119,
    "hanzi": "现在",
    "pinyin": "xiànzài",
    "meaning": "sekarang",
    "category": "time"
  },
  {
    "id": 120,
    "hanzi": "想",
    "pinyin": "xiǎng",
    "meaning": "ingin; berpikir",
    "category": "verb"
  },
  {
    "id": 121,
    "hanzi": "小",
    "pinyin": "xiǎo",
    "meaning": "kecil",
    "category": "adjective"
  },
  {
    "id": 122,
    "hanzi": "小姐",
    "pinyin": "xiǎojiě",
    "meaning": "Nona",
    "category": "person"
  },
  {
    "id": 123,
    "hanzi": "些",
    "pinyin": "xiē",
    "meaning": "beberapa",
    "category": "measure"
  },
  {
    "id": 124,
    "hanzi": "写",
    "pinyin": "xiě",
    "meaning": "menulis",
    "category": "verb"
  },
  {
    "id": 125,
    "hanzi": "谢谢",
    "pinyin": "xièxie",
    "meaning": "terima kasih",
    "category": "phrase"
  },
  {
    "id": 126,
    "hanzi": "星期",
    "pinyin": "xīngqī",
    "meaning": "minggu; pekan",
    "category": "time"
  },
  {
    "id": 127,
    "hanzi": "学生",
    "pinyin": "xuésheng",
    "meaning": "murid; mahasiswa",
    "category": "person"
  },
  {
    "id": 128,
    "hanzi": "学习",
    "pinyin": "xuéxí",
    "meaning": "belajar",
    "category": "verb"
  },
  {
    "id": 129,
    "hanzi": "学校",
    "pinyin": "xuéxiào",
    "meaning": "sekolah",
    "category": "place"
  },
  {
    "id": 130,
    "hanzi": "一",
    "pinyin": "yī",
    "meaning": "satu",
    "category": "number"
  },
  {
    "id": 131,
    "hanzi": "衣服",
    "pinyin": "yīfu",
    "meaning": "pakaian",
    "category": "object"
  },
  {
    "id": 132,
    "hanzi": "医生",
    "pinyin": "yīshēng",
    "meaning": "dokter",
    "category": "person"
  },
  {
    "id": 133,
    "hanzi": "医院",
    "pinyin": "yīyuàn",
    "meaning": "rumah sakit",
    "category": "place"
  },
  {
    "id": 134,
    "hanzi": "椅子",
    "pinyin": "yǐzi",
    "meaning": "kursi",
    "category": "object"
  },
  {
    "id": 135,
    "hanzi": "有",
    "pinyin": "yǒu",
    "meaning": "punya; ada",
    "category": "verb"
  },
  {
    "id": 136,
    "hanzi": "月",
    "pinyin": "yuè",
    "meaning": "bulan",
    "category": "time"
  },
  {
    "id": 137,
    "hanzi": "再见",
    "pinyin": "zàijiàn",
    "meaning": "sampai jumpa",
    "category": "phrase"
  },
  {
    "id": 138,
    "hanzi": "在",
    "pinyin": "zài",
    "meaning": "berada di; sedang",
    "category": "verb"
  },
  {
    "id": 139,
    "hanzi": "怎么",
    "pinyin": "zěnme",
    "meaning": "bagaimana",
    "category": "question"
  },
  {
    "id": 140,
    "hanzi": "怎么样",
    "pinyin": "zěnmeyàng",
    "meaning": "bagaimana; seperti apa",
    "category": "question"
  },
  {
    "id": 141,
    "hanzi": "这",
    "pinyin": "zhè",
    "meaning": "ini",
    "category": "pronoun"
  },
  {
    "id": 142,
    "hanzi": "中国",
    "pinyin": "Zhōngguó",
    "meaning": "Tiongkok; China",
    "category": "place"
  },
  {
    "id": 143,
    "hanzi": "中午",
    "pinyin": "zhōngwǔ",
    "meaning": "siang",
    "category": "time"
  },
  {
    "id": 144,
    "hanzi": "住",
    "pinyin": "zhù",
    "meaning": "tinggal",
    "category": "verb"
  },
  {
    "id": 145,
    "hanzi": "桌子",
    "pinyin": "zhuōzi",
    "meaning": "meja",
    "category": "object"
  },
  {
    "id": 146,
    "hanzi": "字",
    "pinyin": "zì",
    "meaning": "karakter; huruf",
    "category": "noun"
  },
  {
    "id": 147,
    "hanzi": "昨天",
    "pinyin": "zuótiān",
    "meaning": "kemarin",
    "category": "time"
  },
  {
    "id": 148,
    "hanzi": "坐",
    "pinyin": "zuò",
    "meaning": "duduk; naik kendaraan",
    "category": "verb"
  },
  {
    "id": 149,
    "hanzi": "做",
    "pinyin": "zuò",
    "meaning": "melakukan; membuat",
    "category": "verb"
  },
  {
    "id": 150,
    "hanzi": "早上",
    "pinyin": "zǎoshang",
    "meaning": "pagi",
    "category": "time"
  }
];
