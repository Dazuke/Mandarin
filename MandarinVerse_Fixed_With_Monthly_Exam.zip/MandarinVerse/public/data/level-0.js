// Fondasi Pinyin dan empat nada. Level pengantar internal MandarinVerse.
export const level0 = {
  title: "Pinyin & nada Mandarin",
  description: "Kenali bunyi, inisial, final, dan empat nada sebelum memperbanyak kosakata.",
  tones: [
    {tone:"Nada 1",mark:"ā",shape:"Datar dan tinggi",example:"mā"},
    {tone:"Nada 2",mark:"á",shape:"Naik",example:"má"},
    {tone:"Nada 3",mark:"ǎ",shape:"Turun lalu naik",example:"mǎ"},
    {tone:"Nada 4",mark:"à",shape:"Turun tegas",example:"mà"}
  ]
};