// Soal latihan berbasis kosakata HSK 1. Quiz harian memilih 5 soal; ujian memilih hingga 25.
export const sampleQuiz = [
 {hanzi:"你好",pinyin:"nǐ hǎo",question:"Apa arti 你好?",options:["Halo","Terima kasih","Selamat tidur","Maaf"],answer:"Halo"},
 {hanzi:"谢谢",pinyin:"xièxie",question:"Apa arti 谢谢?",options:["Sampai jumpa","Terima kasih","Sama-sama","Silakan"],answer:"Terima kasih"},
 {hanzi:"再见",pinyin:"zàijiàn",question:"Apa arti 再见?",options:["Selamat pagi","Maaf","Sampai jumpa","Halo"],answer:"Sampai jumpa"},
 {hanzi:"老师",pinyin:"lǎoshī",question:"Siapa 老师?",options:["Dokter","Guru","Teman","Murid"],answer:"Guru"},
 {hanzi:"水",pinyin:"shuǐ",question:"Apa arti 水?",options:["Teh","Nasi","Air","Buah"],answer:"Air"},
 {hanzi:"朋友",pinyin:"péngyou",question:"Apa arti 朋友?",options:["Keluarga","Teman","Guru","Orang"],answer:"Teman"},
 {hanzi:"学校",pinyin:"xuéxiào",question:"Apa arti 学校?",options:["Rumah sakit","Toko","Sekolah","Restoran"],answer:"Sekolah"},
 {hanzi:"今天",pinyin:"jīntiān",question:"今天 berarti…",options:["Kemarin","Besok","Hari ini","Tahun depan"],answer:"Hari ini"},
 {hanzi:"吃",pinyin:"chī",question:"Apa arti 吃?",options:["Minum","Makan","Tidur","Pergi"],answer:"Makan"},
 {hanzi:"喜欢",pinyin:"xǐhuan",question:"Apa arti 喜欢?",options:["Membeli","Mengenal","Suka","Menulis"],answer:"Suka"},
 {hanzi:"猫",pinyin:"māo",question:"Hewan apakah 猫?",options:["Anjing","Kucing","Burung","Ikan"],answer:"Kucing"},
 {hanzi:"学生",pinyin:"xuésheng",question:"Apa arti 学生?",options:["Mahasiswa/murid","Dokter","Guru","Ayah"],answer:"Mahasiswa/murid"},
 {hanzi:"明天",pinyin:"míngtiān",question:"明天 berarti…",options:["Sekarang","Besok","Kemarin","Pagi"],answer:"Besok"},
 {hanzi:"中国",pinyin:"Zhōngguó",question:"中国 adalah…",options:["Indonesia","Jepang","China","Korea"],answer:"China"},
 {hanzi:"家",pinyin:"jiā",question:"Apa arti 家?",options:["Sekolah","Rumah/keluarga","Toko","Stasiun"],answer:"Rumah/keluarga"}
];