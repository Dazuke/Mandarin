import { startQuiz } from "./quiz.js";

export function startMonthlyExam() {
  startQuiz("monthly");
}
