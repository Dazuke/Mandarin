import { auth } from "./firebase.js";
import { createUserWithEmailAndPassword, signInWithEmailAndPassword, updateProfile } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";

const loginForm = document.querySelector("#loginForm");
const registerForm = document.querySelector("#registerForm");
const message = document.querySelector("#authMessage");
if (loginForm) loginForm.addEventListener("submit", async e => {
  e.preventDefault(); message.textContent = "Memeriksa akun…";
  try { await signInWithEmailAndPassword(auth, email.value.trim(), password.value); location.href = "index.html"; }
  catch (err) { message.textContent = friendlyError(err.code); }
});
if (registerForm) registerForm.addEventListener("submit", async e => {
  e.preventDefault(); message.textContent = "Membuat akun…";
  try {
    const cred = await createUserWithEmailAndPassword(auth, email.value.trim(), password.value);
    await updateProfile(cred.user, {displayName: displayName.value.trim()});
    location.href = "index.html";
  } catch (err) { message.textContent = friendlyError(err.code); }
});
function friendlyError(code) {
  const map = {"auth/email-already-in-use":"Email sudah terdaftar.","auth/invalid-email":"Format email tidak valid.","auth/weak-password":"Password terlalu lemah.","auth/invalid-credential":"Email atau password salah.","auth/api-key-not-valid":"API key Firebase tidak valid. Periksa konfigurasi Firebase."};
  return map[code] || "Terjadi kendala. Periksa koneksi dan konfigurasi Firebase.";
}