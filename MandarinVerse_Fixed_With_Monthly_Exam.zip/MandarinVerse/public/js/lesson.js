import { hsk1Vocabulary } from "../data/level-1.js";

const lessonTitles = [
  "Salam & perkenalan",
  "Angka, umur & waktu",
  "Keluarga & orang",
  "Makanan & minuman",
  "Aktivitas sehari-hari"
];

export function openLesson(day) {
  const groups = [[0,1,2,3,4],[5,6,7,8,9],[10,11,12,13,14],[15,16,17,18,19],[20,21,22,23,24]];
  const ids = groups[day] || groups[0];
  const words = ids.map(i => hsk1Vocabulary[i]).filter(Boolean);
  const host = document.querySelector("#lessonArea");
  if (!host) return;

  host.innerHTML = `
    <article class="lesson-detail">
      <p class="eyebrow">LESSON DAY ${day + 1}</p>
      <h3>${lessonTitles[day] || "Materi Mandarin"}</h3>
      <p class="muted">Pelajari Hanzi, Pinyin, dan artinya. Baca setiap kata dengan memperhatikan tanda nadanya.</p>
      <div class="lesson-words">
        ${words.map(w => `<div class="lesson-word"><b>${w.hanzi}</b><div><small>${w.pinyin}</small><span class="meaning">${w.meaning}</span></div></div>`).join("")}
      </div>
      <button class="primary-button" data-action="daily-quiz" style="margin-top:16px">Selesai, mulai kuis →</button>
    </article>`;
  host.scrollIntoView({ behavior: "smooth", block: "start" });
}
