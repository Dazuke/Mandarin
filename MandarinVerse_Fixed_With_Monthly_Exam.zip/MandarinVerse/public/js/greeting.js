export function setGreeting(name = "Díkǎ") {
  const hour = new Date().getHours();
  let greeting = "你好";
  if (hour < 11) greeting = "早上好";
  else if (hour < 14) greeting = "中午好";
  else if (hour < 18) greeting = "下午好";
  else greeting = "晚上好";
  const el = document.querySelector("#greeting");
  if (el) el.textContent = `${greeting}, ${name}!`;
  const date = document.querySelector("#dateLabel");
  if (date) date.textContent = new Intl.DateTimeFormat("id-ID",{weekday:"long",day:"numeric",month:"long"}).format(new Date()).toUpperCase();
}