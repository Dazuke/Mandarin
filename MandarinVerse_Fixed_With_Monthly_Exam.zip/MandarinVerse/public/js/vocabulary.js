import { hsk1Vocabulary } from "../data/level-1.js";
export function getVocabulary(){ return hsk1Vocabulary; }
export function renderVocabulary(progress = {}, query = "") {
  const host = document.querySelector("#vocabList"); if (!host) return;
  const q = query.trim().toLowerCase();
  const words = hsk1Vocabulary.filter(w => `${w.hanzi} ${w.pinyin} ${w.meaning}`.toLowerCase().includes(q));
  host.innerHTML = words.map(w => `<article class="vocab-item"><div class="vocab-hanzi">${w.hanzi}</div><div class="vocab-info"><b>${w.pinyin}</b><small>${w.meaning}</small></div><button class="mastery-button ${progress[w.id]?"done":""}" data-master="${w.id}">${progress[w.id]?"Dikuasai":"Tandai"}</button></article>`).join("") || `<p class="muted">Kosakata tidak ditemukan.</p>`;
  document.querySelector("#vocabTotal").textContent = `${words.length} kata`;
}