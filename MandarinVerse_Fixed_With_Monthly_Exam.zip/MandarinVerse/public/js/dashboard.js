import { hsk1Vocabulary } from "../data/level-1.js";
export function renderDashboard(){
 const host=document.querySelector("#todayWords"); if(host)host.innerHTML=hsk1Vocabulary.slice(0,5).map(w=>`<div class="word-mini"><b>${w.hanzi}</b><span>${w.pinyin}</span></div>`).join("");
 const lessons=document.querySelector("#lessonList");
 if(lessons){const names=["Salam & perkenalan","Angka, umur & waktu","Keluarga & orang","Makanan & minuman","Aktivitas sehari-hari","Review mingguan","Ujian mingguan"];
 const desc=["Menyapa dan memperkenalkan diri","Menyebut angka dan waktu sederhana","Mengenal anggota keluarga dan orang","Memesan makanan dan minuman","Kata kerja dan rutinitas sederhana","Ulangi seluruh materi minggu ini","Evaluasi 25 soal"];
 lessons.innerHTML=names.map((n,i)=>`<article class="lesson-row"><span class="lesson-day">${i<5?`D${i+1}`:i===5?"↻":"★"}</span><div><b>${n}</b><p>${desc[i]}</p></div><button data-lesson="${i}">${i===5?"Review":i===6?"Ujian":"Buka"}</button></article>`).join("");}
}