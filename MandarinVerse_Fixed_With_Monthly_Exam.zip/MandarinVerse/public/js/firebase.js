import { initializeApp, getApps } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";

const firebaseConfig = {
  apiKey: "AIzaSyBGhV7PPcNqwYnvSRKqOercbRMlW0V125I",
  authDomain: "valine-b06ad.firebaseapp.com",
  projectId: "valine-b06ad",
  storageBucket: "valine-b06ad.firebasestorage.app",
  messagingSenderId: "188820674947",
  appId: "1:188820674947:web:a1aaf71014823fd504beb6",
  measurementId: "G-M019MMHNX3"
};

const app = getApps().length ? getApps()[0] : initializeApp(firebaseConfig);
export const auth = getAuth(app);
