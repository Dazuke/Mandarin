import { hsk1Vocabulary } from "../data/level-1.js";
import { markMastered, getProgress, renderProgress } from "./progress.js";
export function startReview(){
 const host=document.querySelector("#reviewArea");let i=0;
 const cards=hsk1Vocabulary.slice(0,20);
 const draw=()=>{const w=cards[i%cards.length];host.innerHTML=`<div class="review-flashcard"><p class="eyebrow">KARTU ${i+1} / ${cards.length}</p><div class="hanzi">${w.hanzi}</div><p class="pinyin">${w.pinyin}</p><p class="meaning">${w.meaning}</p><button class="secondary-button" id="masterWord">Sudah dikuasai ✓</button><button class="primary-button" id="nextWord" style="margin-left:7px">Berikutnya →</button></div>`;
 document.querySelector("#masterWord").onclick=()=>{markMastered(w.id);renderProgress();document.querySelector("#masterWord").textContent="Tersimpan ✓";};
 document.querySelector("#nextWord").onclick=()=>{i++;draw();};};draw();
}