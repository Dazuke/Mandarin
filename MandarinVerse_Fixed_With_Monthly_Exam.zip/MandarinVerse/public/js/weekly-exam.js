import { startQuiz } from "./quiz.js";
export function startWeeklyExam(){startQuiz("weekly");}