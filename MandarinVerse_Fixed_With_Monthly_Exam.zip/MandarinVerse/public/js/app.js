import { setGreeting } from "./greeting.js";
import { renderDashboard } from "./dashboard.js";
import { renderVocabulary } from "./vocabulary.js";
import { renderProgress, getProgress, markMastered } from "./progress.js";
import { openLesson } from "./lesson.js";
import { startQuiz, retryQuiz } from "./quiz.js";
import { startWeeklyExam } from "./weekly-exam.js";
import { startMonthlyExam } from "./monthly-exam.js";
import { startReview } from "./review.js";
import { auth } from "./firebase.js";
import { onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";

const views=[...document.querySelectorAll(".view")];
function go(name){
 views.forEach(v=>v.classList.toggle("active",v.dataset.view===name));
 document.querySelectorAll(".nav-item").forEach(b=>b.classList.toggle("active",b.dataset.go===name));
 window.scrollTo({top:0,behavior:"smooth"});
 if(name==="vocab")renderVocabulary(getProgress().mastered,document.querySelector("#vocabSearch").value);
 if(name==="progress")renderProgress();
}
document.addEventListener("click",e=>{
 const nav=e.target.closest("[data-go]");if(nav){go(nav.dataset.go);return;}
 const lesson=e.target.closest("[data-lesson]");if(lesson){openLesson(Number(lesson.dataset.lesson));return;}
 const action=e.target.closest("[data-action]")?.dataset.action;
 if(action==="daily-quiz"){go("exam");startQuiz("daily");}
 if(action==="weekly-exam"){go("exam");startWeeklyExam();}
 if(action==="monthly-exam"){go("exam");startMonthlyExam();}
 if(action==="retry-quiz")retryQuiz();
});
document.querySelector("#vocabSearch").addEventListener("input",e=>renderVocabulary(getProgress().mastered,e.target.value));
document.querySelector("#vocabList").addEventListener("click",e=>{
 const b=e.target.closest("[data-master]");if(!b)return;markMastered(Number(b.dataset.master));renderVocabulary(getProgress().mastered,document.querySelector("#vocabSearch").value);renderProgress();toast("Progress kosakata diperbarui.");
});
document.querySelector("#startReview").addEventListener("click",startReview);
document.querySelector("#profileShortcut").addEventListener("click",()=>go("profile"));
document.querySelector("#logoutButton").addEventListener("click",async()=>{try{await signOut(auth);toast("Berhasil keluar.");}catch{toast("Tidak dapat keluar saat ini.");}});
function toast(msg){const t=document.querySelector("#toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2200);}
setGreeting();renderDashboard();renderVocabulary(getProgress().mastered);renderProgress();
onAuthStateChanged(auth,user=>{
 const email=document.querySelector("#profileEmail"),name=document.querySelector("#profileName"),avatar=document.querySelector("#profileAvatar");
 if(user){email.textContent=user.email||"Akun MandarinVerse";name.textContent=user.displayName||"Díkǎ";avatar.textContent=(user.displayName||"D").slice(0,1).toUpperCase();document.querySelector("#loginLink").hidden=true;document.querySelector("#registerLink").hidden=true;document.querySelector("#logoutButton").hidden=false;}
});
