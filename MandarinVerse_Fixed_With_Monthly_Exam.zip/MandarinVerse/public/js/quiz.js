import { hsk1Vocabulary } from "../data/level-1.js";
import { recordScore } from "./progress.js";

let state = null;

function shuffle(items) {
  return [...items].sort(() => Math.random() - 0.5);
}

function uniqueValues(items, field, correct) {
  const values = [...new Set(items.map(item => item[field]).filter(Boolean))];
  return shuffle(values.filter(value => value !== correct)).slice(0, 3);
}

function makeOptions(words, current, field) {
  const correct = current[field];
  let distractors = uniqueValues(
    words.filter(w => w.category === current.category),
    field,
    correct
  );
  if (distractors.length < 3) {
    distractors = uniqueValues(words, field, correct);
  }
  return shuffle([correct, ...distractors.slice(0, 3)]);
}

function buildQuestionBank() {
  return hsk1Vocabulary.map((word, index) => {
    const kind = index % 3;
    if (kind === 0) {
      return {
        hanzi: word.hanzi,
        pinyin: word.pinyin,
        question: "Apa arti kosakata berikut?",
        options: makeOptions(hsk1Vocabulary, word, "meaning"),
        answer: word.meaning
      };
    }
    if (kind === 1) {
      return {
        hanzi: word.hanzi,
        pinyin: "Pilih Pinyin yang tepat",
        question: "Bagaimana Pinyin dari Hanzi tersebut?",
        options: makeOptions(hsk1Vocabulary, word, "pinyin"),
        answer: word.pinyin
      };
    }
    return {
      hanzi: word.meaning,
      pinyin: "Pilih Hanzi yang sesuai dengan arti",
      question: "Kosakata Mandarin yang memiliki arti tersebut adalah…",
      options: makeOptions(hsk1Vocabulary, word, "hanzi"),
      answer: word.hanzi
    };
  });
}

const PASS_MARKS = { daily: 80, weekly: 80, monthly: 85 };
const QUESTION_COUNTS = { daily: 5, weekly: 25, monthly: 50 };
const LABELS = { daily: "DAILY QUIZ", weekly: "UJIAN MINGGUAN", monthly: "UJIAN BULANAN" };

export function startQuiz(type = "daily") {
  const bank = buildQuestionBank();
  const count = QUESTION_COUNTS[type] || QUESTION_COUNTS.daily;
  const questions = shuffle(bank).slice(0, count);
  state = {
    type,
    questions,
    index: 0,
    correct: 0,
    answered: false,
    passMark: PASS_MARKS[type] || 80
  };
  render();
}

function render() {
  const host = document.querySelector("#quizArea");
  if (!host || !state) return;
  host.hidden = false;

  if (state.index >= state.questions.length) {
    const score = Math.round((state.correct / state.questions.length) * 100);
    const passed = score >= state.passMark;
    recordScore(score, state.type);
    host.innerHTML = `
      <div class="quiz-result">
        <div style="font-size:38px">${passed ? "🎉" : "💪"}</div>
        <p class="eyebrow">HASIL ${LABELS[state.type]}</p>
        <strong>${score}%</strong>
        <h2>${passed ? "Selamat, target tercapai!" : "Belum lulus, waktunya review."}</h2>
        <p class="muted">${state.correct} benar dari ${state.questions.length} soal.</p>
        <p class="muted">${passed
          ? `Kamu melewati batas kelulusan ${state.passMark}%.`
          : `Nilai minimal ${state.passMark}%. Ulangi materi yang belum dikuasai sebelum mencoba lagi.`}</p>
        <button class="primary-button" data-action="retry-quiz">Coba lagi</button>
      </div>`;
    return;
  }

  const q = state.questions[state.index];
  host.innerHTML = `
    <div class="quiz-top"><span>${LABELS[state.type]}</span><span>${state.index + 1}/${state.questions.length}</span></div>
    <div class="quiz-progress"><i style="width:${(state.index / state.questions.length) * 100}%"></i></div>
    <div class="quiz-question">
      <div class="hanzi">${q.hanzi}</div>
      <div class="pinyin">${q.pinyin}</div>
      <h3>${q.question}</h3>
    </div>
    <div class="quiz-answers">
      ${q.options.map(option => `<button class="quiz-answer" data-answer="${option.replaceAll('"', '&quot;')}">${option}</button>`).join("")}
    </div>
    <p id="quizFeedback" class="muted"></p>
    <button id="quizNext" class="primary-button" hidden>${state.index === state.questions.length - 1 ? "Lihat hasil" : "Lanjut →"}</button>`;

  host.querySelectorAll("[data-answer]").forEach(button => {
    button.addEventListener("click", () => answer(button, q));
  });
  host.querySelector("#quizNext").addEventListener("click", () => {
    state.index += 1;
    state.answered = false;
    render();
  });
}

function answer(button, question) {
  if (state.answered) return;
  state.answered = true;
  const isCorrect = button.dataset.answer === question.answer;
  if (isCorrect) state.correct += 1;

  document.querySelectorAll("#quizArea [data-answer]").forEach(option => {
    option.disabled = true;
    if (option.dataset.answer === question.answer) option.classList.add("correct");
  });
  if (!isCorrect) button.classList.add("wrong");

  const feedback = document.querySelector("#quizFeedback");
  if (feedback) {
    feedback.textContent = isCorrect
      ? "Benar! Bagus sekali."
      : `Belum tepat. Jawaban yang benar: ${question.answer}`;
  }
  const next = document.querySelector("#quizNext");
  if (next) next.hidden = false;
}

export function retryQuiz() {
  startQuiz(state?.type || "daily");
}
