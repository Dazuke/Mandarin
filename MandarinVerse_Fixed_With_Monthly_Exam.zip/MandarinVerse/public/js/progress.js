const KEY = "mandarinverse-progress-v1";
const empty = {
  mastered: {},
  xp: 0,
  streak: 0,
  quizScores: [],
  completedLessons: [],
  examHistory: []
};

export function getProgress() {
  try {
    return { ...empty, ...JSON.parse(localStorage.getItem(KEY) || "{}") };
  } catch {
    return { ...empty };
  }
}

export function saveProgress(progress) {
  localStorage.setItem(KEY, JSON.stringify(progress));
}

export function markMastered(id) {
  const progress = getProgress();
  progress.mastered[id] = !progress.mastered[id];
  if (progress.mastered[id]) progress.xp += 5;
  saveProgress(progress);
  return progress;
}

export function addXP(amount) {
  const progress = getProgress();
  progress.xp += amount;
  saveProgress(progress);
  return progress;
}

export function recordScore(score, type = "daily") {
  const progress = getProgress();
  progress.quizScores.push(score);
  progress.examHistory.push({
    type,
    score,
    date: new Date().toISOString()
  });
  progress.xp += score >= (type === "monthly" ? 85 : 80) ? 20 : 5;
  saveProgress(progress);
  return progress;
}

export function renderProgress() {
  const progress = getProgress();
  const count = Object.values(progress.mastered).filter(Boolean).length;
  const percent = Math.round((count / 150) * 100);
  const set = (id, value) => {
    const element = document.getElementById(id);
    if (element) element.textContent = value;
  };

  set("learnedCount", count);
  set("xpCount", `${progress.xp} XP`);
  set("streakCount", progress.streak || 0);
  set("quizAverage", progress.quizScores.length
    ? `${Math.round(progress.quizScores.reduce((a, b) => a + b, 0) / progress.quizScores.length)}%`
    : "—");
  set("progressPercent", `${percent}%`);
  set("progressDetail", `${count} dari 150 kata ditandai dikuasai`);

  const bar = document.getElementById("progressBar");
  if (bar) bar.style.width = `${percent}%`;
}
